#include <stdio.h>
#include <stdlib.h>

unsigned char S[256];
int i, j;

void rc4(unsigned char *key, int key_length) {
    int k;
    unsigned char temp;

    //Initialize S 
    for (i = 0; i < 256; i++) {
        S[i] = i;
    }
    // Key Scheduling Algorithm  KSA
    j = 0;

    for (i = 0; i < 256; i++) {
        j = (j + S[i] + key[i % key_length]) % 256;

        temp = S[i];
        S[i] = S[j];
        S[j] = temp;
    }

    i = 0;
    j = 0;
}
// pseudo random generation algorithm PRGA
unsigned char rc4_byte() {
    unsigned char temp;
    unsigned char output;

    i = (i + 1) % 256;
    j = (j + S[i]) % 256;

    temp = S[i];
    S[i] = S[j];
    S[j] = temp;

    output = S[(S[i] + S[j]) % 256];

    return output;
}

int main() {

    unsigned char key[] = "selam";
   unsigned char *buffer;
   int size;
   FILE *file;
    

    file=fopen("file.txt","rb");
    
    if(file==NULL){
    printf("couldn't open file: \n");
    return 1;
    }
    fseek(file,0,SEEK_END);
    size=ftell(file);
    rewind(file);
    buffer=malloc(size);
    if (buffer == NULL && size > 0) {
        printf("Could not allocate memory\n");
        fclose(file);
        return 1;
    }
    if(size>0){
    fread(buffer,1,size,file);
    }
    
    fclose(file);
    rc4(key, 5);
    for (long n = 0; n < size; n++) {
        buffer[n] = buffer[n] ^ rc4_byte();
    }
    file = fopen("file.txt", "wb");

    if (file == NULL) {
        printf("Could not write to file.txt\n");
        free(buffer);
        return 1;
    }
    if (size > 0) {
        fwrite(buffer, 1,size, file);
    }

    fclose(file);
    free(buffer);
     printf("encrypted");

    return 0;
}
